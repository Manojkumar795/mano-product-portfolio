ALTITUDE Boeing 777-300ER model source

Original aircraft: https://github.com/franck-vmd/Boeing-777-Flightgear
Source file: 777-VMD/Models/Liveries-300ER/777-300.ac (downloaded 8 October 2026).
Source SHA256: ecbb6b77f1467e4d926f0c1d1e2a75da0e4f5b6cee882fe70e10c87d7e2e60cf

Copyright the authors listed in AUTHORS. Original and modified model licensed under GNU GPL version 2; see LICENSE.

ALTITUDE modifications, 8 October 2026: exterior selection, glTF coordinate conversion, white / teal PBR materials, opaque window glazing, cockpit glazing and dark engine interior. No airline identity or endorsement implied.

To reproduce the GLB: install Python, numpy and trimesh, then run:
python convert-777.py 777-300ER.ac boeing-777-300er.glb
The conversion does not use the source model's original livery textures.
