"""Boeing 777 FlightGear AC3D exterior to glTF, ALTITUDE livery. GPL-2.0.
Run: pip install numpy trimesh; python convert-777.py 777-300ER.ac output.glb
Derived model retains its original 777 geometry. Removes interior / deployed gear.
"""
import re, json, sys
from pathlib import Path
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
source=Path(sys.argv[1]);out=Path(sys.argv[2]);lines=source.read_text().splitlines();cursor=0;meshes=[];inventory=[]
while not lines[cursor].startswith('OBJECT'):cursor+=1
white=PBRMaterial(name='ALTITUDE ivory fuselage',baseColorFactor=[246,246,241,255],metallicFactor=.12,roughnessFactor=.34,doubleSided=True)
wing=PBRMaterial(name='Wing alloy',baseColorFactor=[213,219,216,255],metallicFactor=.30,roughnessFactor=.34,doubleSided=True)
teal=PBRMaterial(name='ALTITUDE teal tail',baseColorFactor=[0,105,112,255],metallicFactor=.18,roughnessFactor=.32,doubleSided=True)
glass=PBRMaterial(name='Cabin and cockpit glazing',baseColorFactor=[21,38,44,255],metallicFactor=.15,roughnessFactor=.23,doubleSided=True)
steel=PBRMaterial(name='Engine polished metal',baseColorFactor=[150,164,167,255],metallicFactor=.8,roughnessFactor=.28,doubleSided=True)
black=PBRMaterial(name='Engine fan blades',baseColorFactor=[29,35,39,255],metallicFactor=.45,roughnessFactor=.44,doubleSided=True)
keep=re.compile(r'^(Fuselage(?:\.[0-9]+)?|Fuselageraccord|glassehublot|window mix exterieur|Glass|Vitre.*|Wings[a-z0-9.]*|Tail|Rudder|[LR]Hstab|[LR]Helevator|[LR]aileron[a-z0-9.]*|[LR]flap[a-z0-9.]*|[LR]flaperon|[LR]slat[a-z0-9.]*|[LR]fan|Engines(?:\.[0-9]+)?|Reversers[0-9.]*|[LR]?Inlets(?:\.001)?|[LR]HEngChrome[0-9.]*|moteur[0-9]+|Apu[DG](?:\.001)?|queu pointe|[LR]ramdoor|[LR]Fdoor|[LR]Rdoor|[LR]main.geardoor|[LR]wing.geardoor|entry[0-9]+[lr](?:\.001)?|wiper.[lr])$',re.I)
def obj(parent):
 global cursor
 assert lines[cursor].startswith('OBJECT');cursor+=1
 name='object';vertices=[];faces=[];fmats=[];loc=np.zeros(3);rot=np.eye(3);children=0
 while cursor<len(lines):
  line=lines[cursor];cursor+=1
  if line.startswith('name '):name=line[6:-1]
  elif line.startswith('loc '):loc=np.array(list(map(float,line.split()[1:])))
  elif line.startswith('rot '):rot=np.array(list(map(float,line.split()[1:]))).reshape(3,3)
  elif line.startswith('data '):cursor+=1
  elif line.startswith('numvert '):
   n=int(line.split()[1]);vertices=np.array([list(map(float,l.split())) for l in lines[cursor:cursor+n]]);cursor+=n
  elif line.startswith('numsurf '):
   for i in range(int(line.split()[1])):
    material=0
    while not lines[cursor].startswith('refs '):
     if lines[cursor].startswith('mat '):material=int(lines[cursor].split()[1])
     cursor+=1
    n=int(lines[cursor].split()[1]);cursor+=1;idx=[int(l.split()[0]) for l in lines[cursor:cursor+n]];cursor+=n
    for j in range(1,n-1):faces.append([idx[0],idx[j],idx[j+1]]);fmats.append(material)
  elif line.startswith('kids '):children=int(line.split()[1]);break
 transform=np.eye(4);transform[:3,:3]=rot;transform[:3,3]=loc;transform=parent@transform
 if len(vertices):
  v=trimesh.transform_points(vertices,transform);inventory.append({'name':name,'vertices':len(v),'faces':len(faces),'materials':list(set(fmats)),'min':v.min(0).tolist(),'max':v.max(0).tolist(),'kept':bool(keep.match(name))})
  if keep.match(name) and faces:
   mesh=trimesh.Trimesh(vertices=v,faces=faces,process=True);low=name.lower();mat=white
   if low in ['tail','rudder']:mat=teal
   elif any(n in low for n in ['glasse','glass','vitre','window']):
    mat=glass
    if 'hublot' in low:mesh.vertices[:,2]*=1.018
   elif 'fan' in low or 'inlets' in low:mat=black
   elif 'chrome' in low:mat=black if low.endswith('1.001') else steel
   elif any(n in low for n in ['wings','flap','stab','elevator','aileron','slat']):mat=wing
   if name == 'LHEngChrome':
    c=mesh.triangles_center;radius=np.sqrt((c[:,1]+2.89)**2+(np.abs(c[:,2])-9.89)**2)
    mask=(c[:,0]<-4.6)&(radius<1.64)
    mouth=mesh.submesh([np.flatnonzero(mask)],append=True)
    if len(mouth.faces):
     mouth.visual=trimesh.visual.TextureVisuals(material=black);meshes.append(('Engine inlet interior',mouth))
     mesh=mesh.submesh([np.flatnonzero(~mask)],append=True)
   if name == 'Fuselage':
    # Dark cockpit glazing is separated from the white airframe; no airline branding.
    c=mesh.triangles_center
    mask=(c[:,0]>-29.1)&(c[:,0]<-26.5)&(c[:,1]>.6)&(c[:,1]<1.6)&(np.abs(c[:,2])>1.0)&(np.abs(c[:,2])<2.25)
    cockpit=mesh.submesh([np.flatnonzero(mask)],append=True)
    if len(cockpit.faces):
     cockpit.visual=trimesh.visual.TextureVisuals(material=glass);meshes.append(('Cockpit glazing',cockpit))
     mesh=mesh.submesh([np.flatnonzero(~mask)],append=True)
   mesh.visual=trimesh.visual.TextureVisuals(material=mat);mesh.metadata['name']=name;meshes.append((name,mesh))
 for i in range(children):obj(transform)
obj(np.eye(4))
# All source mesh names and transformations are preserved above.
scene=trimesh.Scene();orient=np.array([[0,0,1,0],[0,1,0,0],[-1,0,0,0],[0,0,0,1]],float)
# Batch identical materials to keep the real-time preview to six draw calls.
from collections import defaultdict
groups=defaultdict(list)
for name,m in meshes:m.apply_transform(orient);groups[m.visual.material.name].append(m)
for name,group in groups.items():
 merged=trimesh.util.concatenate(group);merged.visual=trimesh.visual.TextureVisuals(material=group[0].visual.material);scene.add_geometry(merged,node_name=name,geom_name=name)
print('bounds',scene.bounds,'extents',scene.extents,'meshes',len(meshes),'triangles',sum(len(m.faces) for n,m in meshes));out.write_bytes(scene.export(file_type='glb'));print(out.stat().st_size)
